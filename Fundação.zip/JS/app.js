// Arquivo JS desativado
// O site foi configurado como estático sem Firebase. Este arquivo existia para um painel administrativo com Firebase.
// Se quiser reativar, eu posso restaurar a lógica; por enquanto este arquivo está vazio por segurança.
export default {};
